oppg3.1<-function(){
  data(kap3, envir = environment())
  kap3 <- kap3

  plot(x=kap3$hoyre, y=kap3$omfordeling)
}
