oppg4.3<-function(){
  requireNamespace("datasets")
  data(cars, envir = environment())
  cars <- cars
  ?cars
}
